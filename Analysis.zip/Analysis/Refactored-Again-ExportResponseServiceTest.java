package com.yourpackage;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import com.yourpackage.service.ExportSurveyResponseService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import javax.sql.DataSource;

@DataJpaTest // Used to ensure JPA-related configurations are applied
@ActiveProfiles("test") // Ensure test profile uses H2 database as defined in application-test.yml
@Import(EfmDbContextConfig.class) // Import the context config without modifying it
public class ExportSurveyResponseServiceTest {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Mock
    private ExportSurveyResponseService exportSurveyResponseService;

    @InjectMocks
    private ExportSurveyResponseServiceTest exportSurveyResponseServiceTest;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void contextLoads() {
        // Ensure the context loads and the service is injected
        assertNotNull(exportSurveyResponseService);
    }

    @Test
    public void testDatabaseConnection() throws Exception {
        // Verify that the DataSource is H2 and connections are valid
        try (var connection = dataSource.getConnection()) {
            assertNotNull(connection);
            assertNotNull(jdbcTemplate);
            System.out.println("H2 Database connected successfully.");
        }
    }

    @Test
    public void testExportSurveyResponse() {
        // Mock behavior of service to avoid real database interaction
        when(exportSurveyResponseService.exportSurveyData(any())).thenReturn(true);

        boolean result = exportSurveyResponseService.exportSurveyData("some-input");

        assertNotNull(result);
        verify(exportSurveyResponseService, times(1)).exportSurveyData("some-input");
    }
}
