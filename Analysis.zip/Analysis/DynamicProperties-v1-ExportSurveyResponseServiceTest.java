import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.context.TestPropertySource;
import org.springframework.boot.test.context.DynamicPropertyRegistry;
import org.springframework.boot.test.context.DynamicPropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.yml")
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Slf4j
class ExportSurveyResponseServiceTest {

    @Autowired
    private ExportSurveyResponseService exportSurveyResponseService;

    private static DataSourceH2HibernateProperties dsHibernateProps;

    @DynamicPropertySource
    static void dynamicProperties(DynamicPropertyRegistry registry) {
        Resource resource = new ClassPathResource("application-test.yml");
        Properties props = new Properties();
        try (InputStream is = resource.getInputStream()) {
            props.load(is);
            dsHibernateProps = new Binder(new MapConfigurationPropertySource(props))
                .bind("appeng.aluminum.data.sql.connections.efmDataSource", DataSourceH2HibernateProperties.class)
                .get();
        } catch (IOException e) {
            log.error("Error loading properties from YML file", e);
        }

        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.url", () -> dsHibernateProps.getUrl());
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.user", () -> dsHibernateProps.getUser());
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.password", () -> dsHibernateProps.getPassword());
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.hibernate.generate_statistics",
                () -> dsHibernateProps.getHibernate().getGenerateStatistics());
    }

    @Test
    void testExportSurveyResponse() {
        // Your test logic here
        log.info("Using DataSource URL: {}", dsHibernateProps.getUrl());
        assertNotNull(exportSurveyResponseService);
        // Add assertions and logic for your specific test case
    }
}
