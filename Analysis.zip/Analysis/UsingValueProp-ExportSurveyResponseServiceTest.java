@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.yml")
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)   

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Slf4j
class ExportSurveyResponseServiceTest {

    @Autowired
    private ExportSurveyResponseService exportSurveyResponseService;

    @Value("${appeng.aluminum.data.sql.connections.efmDataSource.url}")
    private String efmDataSourceUrl;

    @Value("${appeng.aluminum.data.sql.connections.efmDataSource.user}")
    private String efmDataSourceUser;

    // ... other properties and test logic

    @Test
    void testExportSurveyResponse() {
        // Your test logic here
        log.info("Using DataSource URL: {}", efmDataSourceUrl);
        assertNotNull(exportSurveyResponseService);
        // Add assertions and logic for your specific test case
    }
}