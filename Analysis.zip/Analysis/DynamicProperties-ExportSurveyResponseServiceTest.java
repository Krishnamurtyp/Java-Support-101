import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@SpringBootTest
public class ExportSurveyResponseServiceTest {

    @DynamicPropertySource
    static void dynamicProperties(DynamicPropertyRegistry registry) {
        try {
            // Load properties from application-test.yml
            Map<String, Object> yamlProperties = loadYamlProperties("src/test/resources/application-test.yml");
            
            // Set properties in the registry
            yamlProperties.forEach((key, value) -> {
                registry.add(key, () -> value.toString());
            });
        } catch (IOException e) {
            throw new RuntimeException("Failed to load YAML properties", e);
        }
    }

    // Method to read the YAML file and convert it into a map
    private static Map<String, Object> loadYamlProperties(String path) throws IOException {
        // Using SnakeYAML to load YAML properties
        org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml();
        return yaml.load(Files.newInputStream(Paths.get(path)));
    }

    @Test
    void testExportSurveyResponse() {
        // Your test logic here, using the dynamically loaded properties
    }
}
