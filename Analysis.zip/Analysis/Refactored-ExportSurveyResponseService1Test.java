import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")  // Ensures that the 'test' profile and application-test.yml are used
@Transactional  // Ensures tests are rolled back after execution
public class ExportSurveyResponseServiceTest {

    @Autowired
    private ExportSurveyResponseService exportSurveyResponseService;

    @Autowired
    private EntityManager entityManager;  // To programmatically insert test data

    @BeforeEach
    public void setUp() {
        // Use the EntityManager to insert some test data into the H2 database
        entityManager.createNativeQuery("CREATE TABLE IF NOT EXISTS survey_responses (response_id INT PRIMARY KEY, response_text VARCHAR(255))")
                .executeUpdate();
        entityManager.createNativeQuery("INSERT INTO survey_responses (response_id, response_text) VALUES (1, 'Sample Response')")
                .executeUpdate();
        entityManager.createNativeQuery("INSERT INTO survey_responses (response_id, response_text) VALUES (2, 'Another Sample Response')")
                .executeUpdate();
    }

    @Test
    public void testExportSurveyResponses() {
        // Act: Call the method to export survey responses
        List<Map<String, Object>> responses = exportSurveyResponseService.exportSurveyResponses();

        // Assert: Validate that responses are not null or empty
        assertNotNull(responses, "The responses should not be null.");
        assertFalse(responses.isEmpty(), "The responses list should not be empty.");
        assertEquals(2, responses.size(), "There should be 2 survey responses.");  // Adjust as needed

        // Validate the content of the first response
        Map<String, Object> firstResponse = responses.get(0);
        assertTrue(firstResponse.containsKey("response_id"), "The response should contain 'response_id'.");
        assertEquals("Sample Response", firstResponse.get("response_text"), "The response text should match.");
    }

    @Test
    public void testNoSurveyResponses() {
        // Clear the database
        entityManager.createNativeQuery("DELETE FROM survey_responses").executeUpdate();

        // Act: Call the method to export survey responses
        List<Map<String, Object>> responses = exportSurveyResponseService.exportSurveyResponses();

        // Assert: Validate that the response list is empty
        assertNotNull(responses, "The responses should not be null.");
        assertTrue(responses.isEmpty(), "The responses list should be empty when there is no data.");
    }
}

