import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.Map;

@SpringBootTest(classes = {
        EfmDbContextConfig.class,
        EfmDbContextConfigTest.class,
        KentaurusAppEfmDbTestConfig.class,
        EfmLocaleDbContextConfig.class
})
@TestPropertySource(locations = "classpath:application-test.yml")
@Transactional
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@EnableConfigurationProperties
class ExportSurveyResponseServiceTest {

    @Autowired
    private ExportSurveyResponseService exportSurveyResponseService;

    private static Map<String, Object> yamlProperties;

    @DynamicPropertySource
    static void dynamicProperties(DynamicPropertyRegistry registry) {
        Resource resource = new ClassPathResource("application-test.yml");
        Yaml yaml = new Yaml();
        try (InputStream is = resource.getInputStream()) {
            yamlProperties = yaml.load(is);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load YAML properties", e);
        }

        // Registering properties dynamically
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.url",
                () -> (String) yamlProperties.get("appeng.aluminum.data.sql.connections.efmDataSource.url"));
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.user",
                () -> (String) yamlProperties.get("appeng.aluminum.data.sql.connections.efmDataSource.user"));
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.password",
                () -> (String) yamlProperties.get("appeng.aluminum.data.sql.connections.efmDataSource.password"));
        registry.add("appeng.aluminum.data.sql.connections.efmDataSource.hibernate.generate_statistics",
                () -> ((Map<String, Object>) yamlProperties.get("appeng.aluminum.data.sql.connections.efmDataSource.hibernate"))
                        .get("generate_statistics"));
    }

    @Test
    void testExportSurveyResponse() {
        // Your test logic here using the dynamically loaded properties
        String url = (String) yamlProperties.get("appeng.aluminum.data.sql.connections.efmDataSource.url");
        assertNotNull(url);
        // More test assertions and logic can go here
    }
}
