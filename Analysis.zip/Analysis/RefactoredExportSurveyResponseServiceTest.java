
package com.example.test;

import com.example.config.EfmDbContextConfigTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@ContextConfiguration(classes = {EfmDbContextConfigTest.class})
@TestPropertySource(locations = "classpath:application-test.yml")
public class ExportSurveyResponseServiceTest {

    @Autowired
    private ExportSurveyResponseService exportSurveyResponseService;

    @Test
    public void testSyncSurveyResponses() {
        // Your existing test logic here
    }
    
    @Test
    public void fetchesAndSavesEveryNewResponse() throws Exception {
        // Your existing test logic here

        // Load application-test.yml properties and use them in the test
        // Ensure properties like database URL and credentials are loaded
    }
}
